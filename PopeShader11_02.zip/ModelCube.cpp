#include "ModelCube.h"

bool ColorCube::InitVertexBuffer( ID3D11Device * pDevice )
{
	ColorVertex vertices[] = {
		{ XMFLOAT3( -1.0f, 1.0f, -1.0f ), XMFLOAT4( 0.0f, 0.0f, 1.0f, 1.0f ) },
		{ XMFLOAT3( 1.0f, 1.0f, -1.0f ), XMFLOAT4( 0.0f, 1.0f, 0.0f, 1.0f ) },
		{ XMFLOAT3( 1.0f, 1.0f, 1.0f ), XMFLOAT4( 0.0f, 1.0f, 1.0f, 1.0f ) },
		{ XMFLOAT3( -1.0f, 1.0f, 1.0f ), XMFLOAT4( 1.0f, 0.0f, 0.0f, 1.0f ) },
		{ XMFLOAT3( -1.0f, -1.0f, -1.0f ), XMFLOAT4( 1.0f, 0.0f, 1.0f, 1.0f ) },
		{ XMFLOAT3( 1.0f, -1.0f, -1.0f ), XMFLOAT4( 1.0f, 1.0f, 0.0f, 1.0f ) },
		{ XMFLOAT3( 1.0f, -1.0f, 1.0f ), XMFLOAT4( 1.0f, 1.0f, 1.0f, 1.0f ) },
		{ XMFLOAT3( -1.0f, -1.0f, 1.0f ), XMFLOAT4( 0.0f, 0.0f, 0.0f, 1.0f ) },
	};

	D3D11_BUFFER_DESC vbd;
	ZeroMemory( &vbd, sizeof( vbd ) );
	vbd.Usage = D3D11_USAGE_DEFAULT;
	vbd.ByteWidth = sizeof( ColorVertex ) * 8;
	vbd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	vbd.CPUAccessFlags = 0;

	D3D11_SUBRESOURCE_DATA vid;
	ZeroMemory( &vid, sizeof( vid ) );
	vid.pSysMem = vertices;

	HRESULT hr = pDevice->CreateBuffer( &vbd, &vid, &m_pVB );
	if( FAILED( hr ) )
		return false;

	return true;
}

bool ColorCube::InitIndexBuffer( ID3D11Device * pDevice )
{
	WORD indicies[] = {
		3,1,0,
		2,1,3,

		0,5,4,
		1,5,0,

		3,4,7,
		0,4,3,

		1,6,5,
		2,6,1,

		2,7,6,
		3,7,2,

		6,4,5,
		7,4,6,
	};

	D3D11_BUFFER_DESC ibd;
	ZeroMemory( &ibd, sizeof( ibd ) );
	ibd.Usage = D3D11_USAGE_DEFAULT;
	ibd.ByteWidth = sizeof( WORD ) * 36;
	ibd.BindFlags = D3D11_BIND_INDEX_BUFFER;
	ibd.CPUAccessFlags = 0;

	D3D11_SUBRESOURCE_DATA iid;
	ZeroMemory( &iid, sizeof( iid ) );
	iid.pSysMem = indicies;

	HRESULT hr = pDevice->CreateBuffer( &ibd, &iid, &m_pIB );
	if( FAILED( hr ) )
		return false;

	return true;
}

UINT ColorCube::GetStride() const
{
	return sizeof( ColorVertex );
}

bool TextureCube::InitVertexBuffer( ID3D11Device * pDevice )
{
	// CREATE VERTEX_BUFFER
	TextureVertex vertices[] =
	{
		{ XMFLOAT3( -1.0f, 1.0f, -1.0f ), XMFLOAT2( 0.0f, 0.0f ) },
		{ XMFLOAT3( 1.0f, 1.0f, -1.0f ), XMFLOAT2( 1.0f, 0.0f ) },
		{ XMFLOAT3( 1.0f, 1.0f, 1.0f ), XMFLOAT2( 1.0f, 1.0f ) },
		{ XMFLOAT3( -1.0f, 1.0f, 1.0f ), XMFLOAT2( 0.0f, 1.0f ) },

		{ XMFLOAT3( -1.0f, -1.0f, -1.0f ), XMFLOAT2( 0.0f, 0.0f ) },
		{ XMFLOAT3( 1.0f, -1.0f, -1.0f ), XMFLOAT2( 1.0f, 0.0f ) },
		{ XMFLOAT3( 1.0f, -1.0f, 1.0f ), XMFLOAT2( 1.0f, 1.0f ) },
		{ XMFLOAT3( -1.0f, -1.0f, 1.0f ), XMFLOAT2( 0.0f, 1.0f ) },

		{ XMFLOAT3( -1.0f, -1.0f, 1.0f ), XMFLOAT2( 0.0f, 0.0f ) },
		{ XMFLOAT3( -1.0f, -1.0f, -1.0f ), XMFLOAT2( 1.0f, 0.0f ) },
		{ XMFLOAT3( -1.0f, 1.0f, -1.0f ), XMFLOAT2( 1.0f, 1.0f ) },
		{ XMFLOAT3( -1.0f, 1.0f, 1.0f ), XMFLOAT2( 0.0f, 1.0f ) },

		{ XMFLOAT3( 1.0f, -1.0f, 1.0f ), XMFLOAT2( 0.0f, 0.0f ) },
		{ XMFLOAT3( 1.0f, -1.0f, -1.0f ), XMFLOAT2( 1.0f, 0.0f ) },
		{ XMFLOAT3( 1.0f, 1.0f, -1.0f ), XMFLOAT2( 1.0f, 1.0f ) },
		{ XMFLOAT3( 1.0f, 1.0f, 1.0f ), XMFLOAT2( 0.0f, 1.0f ) },

		{ XMFLOAT3( -1.0f, -1.0f, -1.0f ), XMFLOAT2( 0.0f, 0.0f ) },
		{ XMFLOAT3( 1.0f, -1.0f, -1.0f ), XMFLOAT2( 1.0f, 0.0f ) },
		{ XMFLOAT3( 1.0f, 1.0f, -1.0f ), XMFLOAT2( 1.0f, 1.0f ) },
		{ XMFLOAT3( -1.0f, 1.0f, -1.0f ), XMFLOAT2( 0.0f, 1.0f ) },

		{ XMFLOAT3( -1.0f, -1.0f, 1.0f ), XMFLOAT2( 0.0f, 0.0f ) },
		{ XMFLOAT3( 1.0f, -1.0f, 1.0f ), XMFLOAT2( 1.0f, 0.0f ) },
		{ XMFLOAT3( 1.0f, 1.0f, 1.0f ), XMFLOAT2( 1.0f, 1.0f ) },
		{ XMFLOAT3( -1.0f, 1.0f, 1.0f ), XMFLOAT2( 0.0f, 1.0f ) },
	};

	D3D11_BUFFER_DESC vbd;
	ZeroMemory( &vbd, sizeof( vbd ) );
	vbd.Usage = D3D11_USAGE_DEFAULT;
	vbd.ByteWidth = sizeof( TextureVertex ) * 24;
	vbd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	vbd.CPUAccessFlags = 0;

	D3D11_SUBRESOURCE_DATA vid;
	ZeroMemory( &vid, sizeof( vid ) );
	vid.pSysMem = vertices;

	HRESULT hr = pDevice->CreateBuffer( &vbd, &vid, &m_pVB );
	if( FAILED( hr ) )
		return false;

	return true;
}

bool TextureCube::InitIndexBuffer( ID3D11Device * pDevice )
{
	WORD indices[] =
	{
		3,1,0,
		2,1,3,

		6,4,5,
		7,4,6,

		11,9,8,
		10,9,11,

		14,12,13,
		15,12,14,

		19,17,16,
		18,17,19,

		22,20,21,
		23,20,22
	};

	D3D11_BUFFER_DESC ibd;
	ZeroMemory( &ibd, sizeof( ibd ) );
	ibd.Usage = D3D11_USAGE_DEFAULT;
	ibd.ByteWidth = sizeof( WORD ) * 36;
	ibd.BindFlags = D3D11_BIND_INDEX_BUFFER;
	ibd.CPUAccessFlags = 0;

	D3D11_SUBRESOURCE_DATA iid;
	ZeroMemory( &iid, sizeof( iid ) );
	iid.pSysMem = indices;

	HRESULT hr = pDevice->CreateBuffer( &ibd, &iid, &m_pIB );
	if( FAILED( hr ) )
		return false;

	return true;
}

UINT TextureCube::GetStride() const
{
	return sizeof( TextureVertex );
}
